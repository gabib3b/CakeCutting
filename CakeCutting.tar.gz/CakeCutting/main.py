__author__ = 'gabib3b'

from evenpaz.allocation import Allocation
import utils.numbersUtil as numbersUtils
import evenpaz.evenpaz1d as evenpazalg
import utils.cakepartitions as cakepartitions
import lastdiminisher.lastdiminisher1d as LastDiminisher
import graphdrawing.drawingUtil as graphDrawing
import numpy as np
import json
import  cairocffi as ff

#from pytesser import *
#from cv2.cv import *



NOISE_PROPORTION = [0.2]
NUMBER_OF_AGENTS = [2,4,8,16,32,64,128]
DATA_FILE_NAME ='data/newzealand_forests_npv_4q.1d.json'
EXPERIMENTS_PER_CELL = 10

"""
last_diminisher_allocations 
"""
def calculateSingleDataPoint(mean_values, num_of_agents, noise_proportion):
    experiment_counter = EXPERIMENTS_PER_CELL
    while experiment_counter > 0:
        values = numbersUtils.noisy_values_array(mean_values, noise_proportion, None, num_of_agents)
        experiment_counter -= experiment_counter

        #last_diminisher_allocations1 = LastDiminisher.last_diminisher_allocation(values)
        allocations = numbersUtils.values_to_allocations(values)
        division_results = evenpazalg.even_paz_dividion(allocations)

        allocations1 = numbersUtils.values_to_allocations(values)
        last_diminisher_allocations1 = LastDiminisher.last_diminisher_allocation(allocations1)

        #appraiser calculation for even paz
        appraiser_values_even_paz = numbersUtils.noisy_values_array(mean_values, 0, None, num_of_agents)
        even_paz_appraiser_allocations = numbersUtils.values_to_allocations(appraiser_values_even_paz)
        even_paz_appraiser_results = evenpazalg.even_paz_dividion(even_paz_appraiser_allocations)

         #appraiser calculation for last_diminisher
        appraiser_values_last_diminisher = numbersUtils.noisy_values_array(mean_values, 0, None, num_of_agents)
        last_diminisher_appraiser_allocations = numbersUtils.values_to_allocations(appraiser_values_last_diminisher)
        last_diminisher_appraiser_results = LastDiminisher.last_diminisher_allocation(even_paz_appraiser_allocations)



        if division_results is not None:
            print(1)


def alg_calculation():

    with open(DATA_FILE_NAME) as json_file:
        meanValues = json.load(json_file)



    for noise_prop in NOISE_PROPORTION:
        print(noise_prop)
        for agents_count in NUMBER_OF_AGENTS:
            print(agents_count)
            #values1 = numbersUtils.noisy_values_array(meanValues, noise_prop, None, agents_count)
            calculateSingleDataPoint(meanValues, agents_count, noise_prop)

    #values1 = np.loadtxt(DATA_FILE_NAME)

    #values1 = numbersUtils.noisy_values_array([1, 2, 3], 0, None, 4)

    values1 = []
    values1.append(numbersUtils.noisy_values_array([5, 7, 5, 4], 0, None, 1)[0])
    values1.append(numbersUtils.noisy_values_array([2, 4, 8, 10], 0, None, 1)[0])
    values1.append(numbersUtils.noisy_values_array([1, 10, 3, 3], 0, None, 1)[0])
    values1.append(numbersUtils.noisy_values_array([5, 6, 1, 5], 0, None, 1)[0])

    allocations = evenpazalg.proportional_division_even_paz(values1)


    last_diminisher_allocations = LastDiminisher.last_diminisher_allocation(allocations)

    egalitarianGain1 = numbersUtils.normalizedEgalitarianValue(last_diminisher_allocations) - 1

    largest_envy = cakepartitions.largest_envy(last_diminisher_allocations)




    egalitarianGain = numbersUtils.normalizedEgalitarianValue(allocations) - 1

    if egalitarianGain < -0.001:
        raise ArithmeticError('In proportional division, normalized egalitarian gain must be at least 0; got ' + egalitarianGain)

    utilitarianGain = numbersUtils.utilitarianValue(allocations) - 1

    if utilitarianGain < -0.001:
        raise ArithmeticError('In proportional division, utilitarian gain must be at least 0; got ' + utilitarianGain)

    largest_envy = cakepartitions.largest_envy(allocations)




    division_results = evenpazalg.even_paz_dividion(allocations)


    for noise in NOISE_PROPORTION:
        for agentNumber in NUMBER_OF_AGENTS:
            print('noise:{0} agencts:{1}'.format(noise, agentNumber))



    a1 = Allocation(0, 1, [1,2,3])

    a2 = Allocation(0, 1, [1,2,3])

x = np.arange(0., 10., 0.5)
y = np.arange(1., 11., 0.5)

alg_calculation()

#graphDrawing. draw_graph([1, 2, 3, 4] , [4, 7, 8, 12], 'my title', 'x', 'y', [0, 30, 0,30])

#graphDrawing. draw_graph(x , y, 'my title', 'x', 'y', [0, 30, 0,30])

x = 5;

