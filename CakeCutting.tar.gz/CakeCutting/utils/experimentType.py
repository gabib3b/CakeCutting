__author__ = 'gabib3b'
from enum import Enum

class ExperimentType(Enum):

    even_paz = 1
    last_diminisher = 2
    even_paz_appraiser =3
    last_diminisher_appraiser = 4,
    even_paz_exchange_jealous = 5
    last_diminisher_exchange_jealous = 6
    even_paz_appraiser_exchange_jealous =7
    last_diminisher_appraiser_exchange_jealous = 8,
    even_paz_env_influence = 9,
    last_diminisher_env_influence = 10,
    even_paz_env_influence_exchange = 12,
    last_diminisher_env_influence_exchange = 13,
    even_paz_fraud_agenct_index = 14,
    last_diminisher_fraud_agent_index = 15,
    even_paz_fraud_agent_index_with_exchange = 16,
    last_diminisher_fraud_agent_index_with_exchange = 17,
    even_paz_fraud_identical = 18,
    last_diminisher_fraud_identical = 19


