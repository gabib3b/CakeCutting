from enum import Enum

__author__ = 'gabib3b'

class AggregationType(Enum):
    Noise = 1,
    NUmberOfAgents = 2