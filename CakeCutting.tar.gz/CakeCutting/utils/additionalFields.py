__author__ = 'gabib3b'


def numberOfExchanges():
    return  'number Of Exchanges'

def fraud_agenct_index():
    return 'fraud_agent_index'