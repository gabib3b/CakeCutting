from results.ExpResult import ExpResult

__author__ = 'gabib3b'

import Exp


def results_object(exp_name, division, num_of_agents, noise):

    results = ExpResult('EVEN_PAZ',   )